# py-tools
collect some commons methods
# build
python setup.py sdist build
#upload
twine upload dist/*